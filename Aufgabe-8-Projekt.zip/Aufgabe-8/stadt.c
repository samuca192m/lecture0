#include "stadt.h"

void stringToCitynew ( CITY * c , const char * s ) {
	c->einwohner = 0 ;
	c->area = 0 ;
	c->einwohnerDichte = 0 ;
	int i = 0 ;
	while ( s [i] != '#' ){
		c->name [i] = s [i] ;
		i ++ ;
	}
	c->name [i] = 0 ;
	i ++ ;
	int j = 0 ;
	char change [20] ;
	while ( s [i] != ' ' ){  //einwohner
		change [j] = s [i] ;
		i ++ ;
		j ++ ;
	} 
	i ++ ;   
	change [j] = 0 ;
	j = 0 ;
	c->einwohner = stringToInt ( change ) ;
	while ( s [i] != '#' ){
		i ++ ;
	}	
	i ++ ;
	while ( s [i] != ' ' ){  // area in km^2
		change [j] = s [i] ;
		i ++ ;
		j ++ ;
	} 
	i ++ ;   
	change [j] = 0 ;
	j = 0 ;
	c->area = stringToInt ( change ) ;	
	while ( s [i] != '#' ){
		i ++ ;
	}	
	i ++ ;	
	while ( s [i] != 0 ){  // Einwohnerdichte
		change [j] = s [i] ;
		i ++ ;
		j ++ ;
	} 
	i ++ ;   
	change [j] = 0 ;
	c->einwohnerDichte = stringToInt ( change ) ;		
	return ;
}

int stringToInt ( const char * s ){
	char c [20] ;
	int i = 0 , j = 0 ;
	while ( 0 != s [i] ){
		if ( s [i] != '.' ){
			c [j] = s [i] ; 
			i ++ ;
			j ++ ;
		} else {
			i ++ ;
		}
	}
	c [j] = 0 ;
	return atoi ( c ) ;
}









