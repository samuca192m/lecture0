#ifndef _STADT_H_
#define _STADT_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

struct city {
	char name [20] ;
	int einwohner ;
	int area ;
	int einwohnerDichte ;
};

typedef struct city CITY ;

//---------------------------------------

void stringToCitynew ( CITY * c , const char * s ) ;

int stringToInt ( const char * s ) ;


#endif
