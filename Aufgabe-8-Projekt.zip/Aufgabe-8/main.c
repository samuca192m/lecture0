#include <stdio.h>
#include <stdlib.h>
#include "land.h"
#define DATEI "./aufgabe-8-europa.csv"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

//----------------------------------------------
//funktionsdefinitionen

int einlesen ( LAND ** , int , int * res ,int * bel ) ;

int vergleichA ( const void * , const void * ) ;

int vergleichB ( const void * va , const void * vb ) ;

int vergleichC ( const void * va , const void * vb ) ;

void statistik ( LAND * , int n , int bel ) ;

void befreien ( LAND ** , int * res , int * bel ) ;

void ausgeben ( LAND * , int n , int bel ) ;

//----------------------------------------------

int main(void) {
	LAND * table = NULL ;
	int res = 0 , bel = 0 ;
	while (true) {
		int i ;
		printf ( "Gib eine Zahl ( 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 ):\n") ;
		printf ( "1 : Einlesen\n" ) ;
		printf ( "2 : Ausgeben\n" ) ;
		printf ( "3 : Loeschen\n" ) ;
		printf ( "4 : Statistik\n" ) ;
		printf ( "5 : Sortieren ( Laendername (a-z) )\n" ) ;
		printf ( "6 : Sortieren (  BIP absteigend )\n" ) ;
		printf ( "7 : Sortieren (  Einwohnerzahl der Hauptstadt (aufsteigend) )\n" ) ;
		printf ( "8 : Beenden\n" ) ;
		scanf ( "%d" , &i ) ;
		if ( 1 == i ){
			einlesen ( &table , 37, &res , &bel ) ;
		}
		if ( 2 == i ){
			ausgeben ( table , 37 , bel ) ;
		}
		if ( 3 == i ){
			befreien ( &table , &res , &bel ) ;
		}
		if ( 4 == i ){
			statistik ( table , 37 , bel ) ;
		}
		if ( 5 == i ){
			qsort ( (void*) table , 37 , sizeof ( LAND ) , vergleichA ) ;
		}
		if ( 6 == i ){
			qsort ( (void*) table , 37 , sizeof ( LAND ) , vergleichB ) ;
		}
		if ( 7 == i ){
			qsort ( (void*) table , 37 , sizeof ( LAND ) , vergleichC ) ;
		}
		if ( 8 == i ){
			break ;
		}														
	}	
	return 0;
}

int einlesen ( LAND ** l , int n , int * res , int * bel ){
	FILE * p = fopen ( DATEI , "r" ) ;
	if ( NULL == p ) {
		printf ( "Fehler! Datei kann nicht geoeffnet werden!" ) ;
		return -1 ;
	}	
	char buffer [500] = "" ;
	fgets ( buffer , sizeof ( buffer ) -1 , p ) ;
	int j , k = 0 ;
	bool ende = false ;
	for ( j = 0 ; j < n ; j ++ ){
		fgets ( buffer , sizeof ( buffer ) -1 , p ) ;
		k = 0 ;
		ende = false ;
		if (*res == *bel ){
			*l = realloc ( *l , ( 5 + (*res) )*sizeof (LAND) ) ;
			(*res) += 5 ;
		}
        stringToLand ( ( *l + j ) , buffer ) ;
        (*bel) ++ ;
	}
	fclose ( p ) ;
	return 0 ;
}

int vergleichA ( const void * va , const void * vb ){
	if ( (*((LAND*)va)).name [0] > (*((LAND*)vb)).name [0] ){
		return 1 ;
	}
	if ( (*((LAND*)va)).name [0] == (*((LAND*)vb)).name [0] ){
		return 0 ;
	}
	if ( (*((LAND*)va)).name [0] < (*((LAND*)vb)).name [0] ){
		return -1 ;
	}		
}

int vergleichB ( const void * va , const void * vb ){
	if ( (*((LAND*)va)).BIP < (*((LAND*)vb)).BIP ){
		return 1 ;
	}
	if ( (*((LAND*)va)).BIP == (*((LAND*)vb)).BIP ){
		return 0 ;
	}
	if ( (*((LAND*)va)).BIP > (*((LAND*)vb)).BIP ){
		return -1 ;
	}	
}

int vergleichC ( const void * va , const void * vb ){
	if ( (*((LAND*)va)).HS.einwohner > (*((LAND*)vb)).HS.einwohner ){
		return 1 ;
	}
	if ( (*((LAND*)va)).HS.einwohner == (*((LAND*)vb)).HS.einwohner ){
		return 0 ;
	}
	if ( (*((LAND*)va)).HS.einwohner < (*((LAND*)vb)).HS.einwohner ){
		return -1 ;
	}	
}

void statistik ( LAND * l , int n , int bel ){
	int i ;
	int count = 0 ; 
	int KL = 0 ;
	int HED = 0 ;
	if ( bel ){
	for ( i = 0 ; i < n ; i ++ ){
		count += (*(l + i)).HS.einwohner ;
	}
	printf ( "Gesamteinwohnerzahl der Hauptst�dte: %d\n" , count ) ;
	count = 0 ;
	for ( i = 0 ; i < n ; i ++ ){
		count += (*(l + i)).kaufKraft ;
	}
	printf ( "Kaufkraft pro Kopf �ber alle Laender: %f\n" , ( (double) count ) / n ) ;
	for ( i = 1 ; i < n ; i ++ ){
		if ( (*(l + i)).area < (*(l + KL)).area ) KL = i ;
	}	
	printf ( "Das fl�chenmae�ig kleinste Land: %s\n" , (*(l + KL)).name ) ;
	for ( i = 1 ; i < n ; i ++ ){
		if ( (*(l + i)).HS.einwohnerDichte > (*(l + HED)).HS.einwohnerDichte ) HED = i ;
	}	
	printf ( "Hauptstadt mit der h�chsten Einwohnerdichte: %s\n" , (*(l + HED)).HS.name ) ;		
	} 	
}

void befreien ( LAND ** l , int * res , int * bel ){
	free ( (void*) *l ) ;
	*l = NULL ;
	*res = *bel = 0 ;
	return ;
}

void ausgeben ( LAND * table , int n , int bel ){
	int i ;
	if ( bel ){
		for ( i = 0 ; i < n ; i ++ ){
	    printf ( "Land: %s ;Fl�che in km�: %d;Einwohner: %d;Bev�lkerungsdichte: %f;\nBIP Mrd. $: %f;" 
	     "Kaufkraft p. P.: %d;Hauptstadt: %s , Einwohner: %dFl�che: %d , Einwohnerdichte: %d\n\n" , 
		 (table + i)->name , (table + i)->area , (table + i)->einwohner , (table + i)->BD ,
		  (table + i)->BIP , (table + i)->kaufKraft , (table + i)->HS.name ,
		   (table + i)->HS.einwohner , (table + i)->HS.area , (table + i)->HS.einwohnerDichte ) ;		
	    }	
	}
	return ;	
} 












