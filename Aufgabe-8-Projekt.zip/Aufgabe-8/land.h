#ifndef _LAND_H_
#define _LAND_H_

#include <stdio.h>
#include <stdlib.h>
#include "stadt.h"

struct land {
	char name [20] ;
	int area ;
	int einwohner ;
	double BD ;
	double BIP ;
	int kaufKraft ;
	CITY HS ; // Hauptstadt
};

typedef struct land LAND ;

void stringToLand ( LAND * , char * ) ;




#endif
