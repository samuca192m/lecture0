#include "land.h"

void stringToLand ( LAND * l , char * s ){
	int i , j = 0 , k = 0 , m ;
	char change [200] ;
	for ( i = 0 ; i < 6 ; i ++ ){
		while ( ';' != s [j] ){
			change [k] = s [j] ;
			if ( s [j] == ','){
				change [k] = '.' ;
			}
			k ++ ;
			j ++ ;
		}
		j ++ ;
		change [k] = 0 ;
		if ( 0 == i ) {
			for ( m = 0 ; m <= k ; m ++ ){
				l->name [m] = change [m] ;
			}
		}
		if ( 1 == i || 2 == i || 5 == i ) {
			if ( 1 == i ){
				l->area = stringToInt ( change ) ;
			}
			if ( 2 == i ){
				l->einwohner = stringToInt ( change ) ;
			}
			if ( 5 == i ){
				l->kaufKraft = stringToInt ( change ) ;
			}						
		}
		if ( 3 == i || 4 == i ) {
			if ( 3 == i ){
				l->BD = atof ( change ) ;
			}
			if ( 4 == i ){
				l->BIP = atof ( change ) ;
			}						
		}
		k = 0 ;
	}
	while ( 0 != s [j] ){
		change [k] = s [j] ;
		k ++ ;
		j ++ ;
	}
	change [k] = 0 ;
	CITY * ci = &(l->HS) ;
	stringToCitynew ( ci , change ) ;
	return ;
}



